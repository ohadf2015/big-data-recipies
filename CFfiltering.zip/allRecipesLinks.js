const cheerio = require('cheerio');
const fsp = require('fs').promises
const XLSX = require('xlsx');
const request = require('request-promise');
const { readFileSync, link } = require('fs');



let recipesSiteUrl = 'https://www.allrecipes.com/recipes'

main().then(() => console.log("YAY- Done:-)"))



async function main() {

  // let browser=await openbrowser()
  // let page=browser[1]
  // browser=browser[0]

  let links = await scrapeRecipesHeaders()



  writeData(links)
  //browser.close()
}

//get categories links and names
async function getRecipesCategoryHeaders() {
  let html = await getHtmlReq(recipesSiteUrl)
  //console.log(html)
  const $ = cheerio.load(html);
  const recCategoriesIndex = $('a.recipeCarousel__link')
  // console.log(recIndex)
  let links = []
  recCategoriesIndex.each(function (i, elem) {
    let recCategoryLink = $(this).attr('href')
    let recCategoryName = $(this).attr('data-tracking-content-headline')
    links.push({ category: recCategoryName, link: recCategoryLink })
  })
  // console.log(links)          
  return links
}

//get TatCategories links and names
async function getRecipesTatCategoryHeaders(link, category) {
  let html = await getHtmlReq(link)
  //console.log(html)
  const $ = cheerio.load(html);
  const recTatCategoriesIndex = $('a.recipeCarousel__link')
  // console.log(recIndex)
  let tatlinks = []
  recTatCategoriesIndex.each(function (i, elem) {
    let recCategoryLink = $(this).attr('href')
    let recTatCategoryName = $(this).attr('data-tracking-content-headline').trim()
    tatlinks.push({ category: category, Tatcategory: recTatCategoryName, link: recCategoryLink })
  })
  //  console.log(tatlinks)          
  return tatlinks
}


async function scrapeRecipesHeaders() {
  const recCategories = await getRecipesCategoryHeaders();
  let arrRecipes = []
  //loop through categories
  console.log(recCategories.length)
  for (let index = 0; index < recCategories.length; index++) {
    const recTatCategories = await getRecipesTatCategoryHeaders(recCategories[index].link, recCategories[index].category);
    // loop through Tatcategories
    process.stdout.write('collecting ' + (((index) / recCategories.length) * 100).toFixed(2) + '% complete...' + recCategories[index].category + '\r');
    for (let tatindex = 0; tatindex < recTatCategories.length; tatindex++) {
      //get recepies links in the current TatCategory (first page)
      let firstPageRecipes = await scrapeFirstPage(recTatCategories[tatindex].link, recTatCategories[tatindex].category, recTatCategories[tatindex].Tatcategory)
      arrRecipes.push(...firstPageRecipes)
      //loop through the main category pages
      let error = false;
      for (let page = 2; !error; page++) {
        let link = `${recTatCategories[tatindex].link}?page=${page}`
        //get the second page, if returned null then stopping the loop
        let recipiesLinks = await scrapePage(link, recTatCategories[tatindex].category, recTatCategories[tatindex].Tatcategory)
        if (recipiesLinks === null || recipiesLinks.length === 0) {
          error = true;
        }
        else arrRecipes.push(...recipiesLinks);
      }
    }

    console.log(arrRecipes.length)
  }
  return arrRecipes
}

//get category first page data
async function scrapeFirstPage(link, category, Tatcategory) {
  const html = await getHtmlReq(link)
  if (!html) return null
  const $ = cheerio.load(html);
  const recCardIndex = $('div.card__detailsContainer-left a.card__titleLink')
  //console.log(recCardIndex)
  let pageRecipe = []
  //get category data + link and time
  recCardIndex.each(function (i, el) {
    let recLink = $(this).attr('href')
    //link='https://www.allrecipes.com'+link
    pageRecipe.push({ link: recLink, category: category, Tatcategory: Tatcategory })
    // console.log(pageRecipe)
  })
  return pageRecipe
}

//get category page data
async function scrapePage(link, category, Tatcategory) {
  const html = await getHtmlReq(link)
  if (!html) return null
  const $ = cheerio.load(html);
  //Check if the page exists - if not returning null
  const errorIndex = $('#error-page__404');
  if (errorIndex == null) return null;
  const recCardIndex = $('a.tout__titleLink')
  let pageRecipe = []
  //console.log("TRY"+recCardIndex)
  //get category data + link 
  recCardIndex.each(function (i, el) {
    let recLink = $(this).attr('href')
    let linkRec = 'https://www.allrecipes.com/' + recLink
    pageRecipe.push({ link: linkRec, category: category, Tatcategory: Tatcategory })
    //console.log(pageRecipe)
  })
  return pageRecipe
}


async function scrapeRecipe(recipeMetaData) {
  let html = await getHtmlReq(recipeMetaData.link)
  if (!html) return null
  const $ = cheerio.load(html);
  let recipeName = $('h1.headline').text()
  let recCat = $('ol.breadcrumbs__list li a').children('span.breadcrumbs__title')
  let catName = recCat.eq(1).text()
  let tatCatName = recCat.eq(3).text()
  //console.log(tatCatName)


  let result = { name: recipeName, category: catName, tatCatName: tatCatName }
  result.category = recipeMetaData.category
  result.link = recipeMetaData.link

  return result
}

// json format

async function writeData(recipiesData) {
  let thisJson = JSON.stringify(recipiesData)
  fsp.writeFile("./data.json", thisJson).catch(err => console.log(err))
  /*recipiesData=recipiesData.map(arr=>{
  arr.instructions=arr.category.toString()
  arr.ingredients=arr.ingredients.toString()
  arr.tags=arr.tags.toString()
  return arr
  })*/



  // Exports all the data to an excel file 

  let result_xl = XLSX.utils.book_new({});
  let recipies = XLSX.utils.json_to_sheet(recipiesData)
  XLSX.utils.book_append_sheet(result_xl, recipies, "allRecipes");
  XLSX.writeFile(result_xl, 'allRecipes.xlsx', { cellDates: true });
}



async function getHtmlReq(link) {
  // console.log(link)
  const html = await request.get(link).catch((err) => { if (err) return false })
  if (!html) {
    return false
  }
  return html
}
