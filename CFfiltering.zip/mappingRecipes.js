
const _=require('lodash')
const fs=require('fs')
const XLSX=require('xlsx')
const path=require('path')
const JSONStream = require('JSONStream')
, es = require('event-stream')
const { isArray } = require('util')


function getTimeValue(time){
let days=time.split('P')[1].split('DT')[0]
let hours=time.split('P')[1].split('DT')[1].split('H')[0]
let min=time.split('P')[1].split('DT')[1].split('H')[1].split('M')[0]

return ((days*24*60)+(hours*60)+min*1)
}


let allData=[]
let counter=0;


    const RS=fs.createReadStream(path.join('./data','allRecipes.json'))

    const parseStream = JSONStream.parse().on('data',function(data){
        if(data&&data.mainEntityOfPage&&data.reviews&&data.reviews.length){
            data.RecId=parseInt(data.mainEntityOfPage.split('recipe/')[1].split('/')[0])
            delete data.reviews
            delete data.review
            delete data['@context']
            delete data['@type']
            data.link=data.mainEntityOfPage
            delete data.mainEntityOfPage 
            delete data.author
            data.rating=data.aggregateRating 
            delete data.aggregateRating 
            delete data.recipeCuisine 
            data.img=data.image.url
            delete data.image
            if(!data.prepTime){
                data.prepTimeVal=60
                data.cookTimeval=60
                data.totalTimeVal=60
            }
            else{
                data.prepTimeVal=getTimeValue(data.prepTime)
                if(!data.cookTime){
                    data.cookTimeval=0
                }
                else{
                    data.cookTimeval=getTimeValue(data.cookTime)
                }
                data.totalTimeVal=getTimeValue(data.totalTime)
            }

            delete data.totalTime
            delete data.cookTime
            delete data.prepTime
            delete data.rating['@type']
            delete data.rating['itemReviewed']
            data.ratingCount=data.rating.ratingCount*1
            data.bestRating=data.rating.bestRating*1
            data.worstRating=data.rating.worstRating*1
            data.rating=data.rating.ratingValue*1
            if(data.nutrition){

                delete data.nutrition['@type']
            }
            if(isArray(data.recipeInstructions)){

                data.recipeInstructions.forEach(arr=>{delete arr['@type']})
            }
                counter++;
                process.stdout.write('processing ' + ((counter/85200)*100).toFixed(2) + '% complete...\r');
             
allData.push(data)
    
                }});
            
          
           
            
            

 
       

        







     RS.pipe(parseStream).on('end',function(hi){
         console.log('done mapping') 
allData=_.uniqBy(allData,'link')
allData=JSON.stringify(allData)
fs.writeFileSync('./data/onlyRecipesData.json',allData)
        })






