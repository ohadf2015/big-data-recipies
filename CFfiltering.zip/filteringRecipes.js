const fs=require('fs')
const _=require('lodash')
let recipes=JSON.parse(fs.readFileSync('./data/onlyRecipesData.json'))
recipes=_.filter(recipes,function(o){
    return o.ratingCount>=10
})

recipes=JSON.stringify(recipes)
fs.writeFileSync('./data/filteredRecipes.json',recipes)