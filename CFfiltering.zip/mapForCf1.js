const _=require('lodash')
const fs=require('fs')
const XLSX=require('xlsx')
let counter=1
let data=JSON.parse(fs.readFileSync('./data/newReviewsCF.json'))
let dataForCsv=[]
for(let i=0;i<data.length;i++){
let flag=false
    let object={}
    object[data[i].userId]=data[i].rating
    if(i>0){

        for(k=0;k<dataForCsv.length;k++){
            if(dataForCsv[k].recipeId==data[i].recipeId){
                flag=k
                break
            }
        }
        if(flag){
         
            dataForCsv[flag][data[i].userId]=data[i].rating
        }
        else{
            dataForCsv.push({recipeId:data[i].recipeId,...object})
        }
    }
    else{
 
let newObj={}
newObj[data[i].userId]=data[i].rating
newObj['recipId']=data[i].recipeId

        dataForCsv.push(newObj)
    }
    counter++
    process.stdout.write('processing ' + ((counter/data.length)*100).toFixed(2) + '% complete...\r');
}




dataForCsv= XLSX.utils.json_to_sheet(dataForCsv) 
console.log('done transforming to csv')
let output_file_name = "forPythonNew.csv";
let stream = XLSX.stream.to_csv(dataForCsv);
stream.pipe(fs.createWriteStream(output_file_name));