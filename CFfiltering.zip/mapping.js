
const _ = require('lodash')
const fs = require('fs')
const XLSX = require('xlsx')
const path = require('path')
const JSONStream = require('JSONStream')
    , es = require('event-stream')



let recipesBook = []

let dataForPython = []

let counter = 0;
const RS = fs.createReadStream(path.join('./data', 'allRecipes.json'))

const parseStream = JSONStream.parse().on('data', function (data) {
    if (data && data.mainEntityOfPage && data.reviews && data.reviews.length) {

        data.RecId = parseInt(dataa.mainEntityOfPage.split('recipe/')[1].split('/')[0])
        data.reviewsData = []
        recipesBook.push({ id: data.RecId, name: data.name, link: data.mainEntityOfPage })
        data.reviews.forEach(review => {
            let object = {}
            object[review.submitter_id] = review.rating
            data.reviewsData.push(object)
        })
        data = _.pick(data, ['RecId', 'reviewsData'])
        data.reviewsData.forEach(review => {
            let reviewKey = Object.keys(review)
            data[reviewKey[0]] = review[reviewKey[0]]
        })
        delete data.reviewsData
        dataForPython.push(data)

        counter++;
        process.stdout.write('processing ' + ((counter / 85200) * 100).toFixed(2) + '% complete...\r');

    }

})


RS.pipe(parseStream).on('end', function (hi) {
    console.log('done mapping')
    dataForPython = XLSX.utils.json_to_sheet(dataForPython)
    console.log('done transforming to csv')
    let output_file_name = "forPython.csv";
    let stream = XLSX.stream.to_csv(dataForPython);
    stream.pipe(fs.createWriteStream(output_file_name));

    recipesBook = XLSX.utils.json_to_sheet(recipesBook)
    let result_xl1 = XLSX.utils.book_new({});
    XLSX.utils.book_append_sheet(result_xl1, recipesBook, "ספר מתכונים");
    XLSX.writeFile(result_xl1, 'ספר מתכונים.xlsx', { cellDates: true });
    recipesBook = []

})






