
const _ = require('lodash')
const fs = require('fs')
const XLSX = require('xlsx')
const path = require('path')
const JSONStream = require('JSONStream')
    , es = require('event-stream')




let categories = []
let counter = 0;

const RS = fs.createReadStream(path.join('./data', 'allRecipes.json'))

const parseStream = JSONStream.parse().on('data', function (data) {
    if (data && data.mainEntityOfPage && data.reviews && data.reviews.length) {

        data.recipeCategory.forEach(el => {
            let flag = false
            categories.forEach(category => {
                if (category.name == el) {
                    category.numRec++
                    flag = true
                }
            })
            if (!flag) {
                categories.push({ name: el, numRec: 1 })

            }
        })
    }

    counter++;
    process.stdout.write('processing ' + ((counter / 85200) * 100).toFixed(2) + '% complete...\r');


});






// data.RecId=parseInt(data.mainEntityOfPage.split('recipe/')[1].split('/')[0])
// data.reviewsData=[]
// recipesBook.push({id:data.RecId,name:data.name,link:data.mainEntityOfPage})
// data.reviews.forEach(review=>{
//     let object={}
//     object[review.submitter_id]=review.rating
//     data.reviewsData.push(object)
// })
// data=_.pick(data,['RecId','reviewsData'])
// data.reviewsData.forEach(review=>{
// let reviewKey=Object.keys(review)
// data[reviewKey[0]]=review[reviewKey[0]]
// })
// delete data.reviewsData
// dataForPython.push(data)




//     for(let i=0;i<links.length;i++){

//         if(links[i]&&data&&data.mainEntityOfPage&&(links[i].link.trim()==data.mainEntityOfPage.trim())){
//         // console.log(data.mainEntityOfPage,links[i].link)
//          links.splice(i,1)
//          console.log(links.length)
//         break
//     }
// }



// links=JSON.stringify(links) 
// fs.writeFileSync('./newLinks.json',links)



RS.pipe(parseStream).on('end', function (hi) {
    console.log('done mapping')
    //          dataForPython= XLSX.utils.json_to_sheet(dataForPython) 
    //          console.log('done transforming to csv')
    //          let output_file_name = "forPython.csv";
    //          let stream = XLSX.stream.to_csv(dataForPython);
    // stream.pipe(fs.createWriteStream(output_file_name));

    //          recipesBook=XLSX.utils.json_to_sheet(recipesBook)
    //          let result_xl1=XLSX.utils.book_new({});
    //          XLSX.utils.book_append_sheet(result_xl1, recipesBook, "ספר מתכונים");
    //          XLSX.writeFile(result_xl1,'ספר מתכונים.xlsx',{cellDates:true}); 
    // recipesBook=[]

    categories = _.sortBy(categories, ['numRec'], ['desc'])

    categories = JSON.stringify(categories)
    fs.writeFileSync('./data/recipesCategoriesCounter.json', categories)
})






