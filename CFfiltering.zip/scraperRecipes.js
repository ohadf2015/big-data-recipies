const cheerio = require('cheerio');
const fsp=require('fs').promises
const fs=require('fs')
const XLSX = require('xlsx');
const puppeteer = require('puppeteer');
const request = require('request-promise');
const { isArray } = require('util');
const _=require('lodash')

// let result=[]

// console.log(NODE_OPTIONS)
// NODE_OPTIONS="--max-old-space-size=4000"

//  'https://www.allrecipes.com/element-api/content-proxy/reviews/?id=270860&page=5'

//  getRecipeData(270860)






let DataNumber=1

let counter=0

main()

async function main(){
 // const browser= await puppeteer.launch({headless:true}).catch(err=>console.log(err));
// const [page]=await browser.pages().catch(err=>console.log(err))
// let $=await getHtml(link,page)

// let link="https://www.allrecipes.com/recipe/132358/easy-garlic-lemon-scallops/"
// console.time("request")
// const $=await getHtmlReq(link)
// console.timeEnd("request")

let path="./newLinks1.json"
let links=fs.readFileSync(path);
links=JSON.parse(links)
links=_.uniqBy(links,'link')
// let data=await iterateLinks(path,17500,17503)
// console.log(result)
// links=links.slice(17500,17510)
console.log(links.length)
let numlinks=links.length
// let numlinks=links.length
let numIterates=parseInt(numlinks/10)
let startLinkNum=0
// let startLinkNum=1

let promises=[]
for(let i=startLinkNum;i<=links.length;i+=numIterates){
  console.log(i,i+numIterates)
  const promise=iterateLinks(links,i,i+numIterates)
      promises.push(promise)
    }
    // console.log(promises)
    // const promise1 = iterateLinks(path,17500,18000);
    // const promise2 = iterateLinks(path,18500,19000);
    // const promise3 = iterateLinks(path,19500,20000)
    // const promise4 = iterateLinks(path,20500,21000)
    // const promise5 = iterateLinks(path,21500,22000)
    // const promise6 = iterateLinks(path,22500,23000)
    // const promise7 = iterateLinks(path,23500,24000)
    Promise.all(promises).then((values) => {
  // startLinkNum+=numIterates
  console.log(`all the data saved successfully!`)
  // return startLinkNum
    });



}




async function scrapeRecipe(link){


  let recipeId=link.split("/recipe/")[1]
  if(recipeId){
    recipeId=recipeId.split("/")[0]
 
 
  
let reviews=await getRecipeReviews(recipeId)
let html=await getHtmlReq(link)
if(html){

const $=cheerio.load(html)

let rating=$('div.recipe-reviews')
let ratingData=null
if(rating.attr('data-rating-counts')){

ratingData=JSON.parse(rating.attr('data-rating-counts'))
}
let recipeData=null
if(($('script[type="application/ld+json"]')[0].children[0].data)[1]){

 recipeData=JSON.parse($('script[type="application/ld+json"]')[0].children[0].data)[1]
}
let Recresult=
{
  reviews,ratingData,...recipeData}
// scrapeComments(link,result)
return Recresult
// console.log(result.review)
}
}
}

async function getRecipeReviews(id){
  let thisData=[]
  let counter=1
    let baseRoot='https://www.allrecipes.com/element-api/content-proxy/reviews/'
    let thisLink=`${baseRoot}?id=${id}&page=${counter}&reviews_count=100000&sort=&is_reviews_page=true`
    let html=await getHtmlReq(thisLink).catch(err=>console.log(err))
  if(html){
    let data=JSON.parse(html)
    data=data.reviews
    if(data&&isArray(data)){
  while(data.length>0){
    thisData.push(...data)
    // console.log(thisData)
    counter++
    let thisLink=`${baseRoot}?id=${id}&page=${counter}&reviews_count=100000&sort=&is_reviews_page=true`
    html=await getHtmlReq(thisLink).catch(err=>console.log(err))
    if(!html){
break
    }
    data=JSON.parse(html)
    
    data=data.reviews
    // console.log('page number' +" "+counter)
  }
}
  }
  return thisData
    // thisData=JSON.stringify(thisData)
    // fsp.writeFile("./Newdata.json",thisData).catch(err=>console.log(err))
  
  
  }



async function writeData(recipesData){
    let thisJson=JSON.stringify(recipesData) 
    // console.log(thisJson)
    fsp.writeFile(`./data/data${DataNumber}.json`,thisJson).catch(err=>console.log(err))
DataNumber++

    recipesData=recipesData.map(arr=>{
for (const key in arr) {
  if (arr.hasOwnProperty(key)) {
    if(isArray(arr[key])){
      arr[key].toString()
    }}
}
    return arr
})


// for (const key in recipesData) {
//   if (recipesData.hasOwnProperty(key)) {
//     if(isArray(recipesData[key])){
//       recipesData[key].toString()
//     }}
// }



// let result_xl=XLSX.utils.book_new({});
// let recipes=XLSX.utils.json_to_sheet(recipesData)
// XLSX.utils.book_append_sheet(result_xl, recipes, "מתכונים");
// XLSX.writeFile(result_xl,'allRecipes.xlsx',{cellDates:true}); 
}



  async function getHtmlReq(link){
    // console.log(link)
    const html = await request.get(link).catch((err)=>{if(err)return false})
    if(!html){
      return false  
    }
    return html
  }





async function iterateLinks(links,since,until){
let result=[]
if(until>links.length){
  until=links.length
}
for(let i=since;i<until;i++){
  if(links[i]&&links[i].link){
    let thisData=await scrapeRecipe(links[i].link)
    if(thisData){
    if(links[i].category){

      thisData.category=links[i].category
    }
    if(links[i].Tatcategory){

      thisData.Tatcategory=links[i].Tatcategory
    }
  }
  result.push(thisData)
// console.log(thisData)
counter++;
  process.stdout.write('collecting ' + ((counter/links.length)*100).toFixed(2) + '% complete...\r');
  }
}


writeData(result)
result=[]
// return result

}








  // async function getHtml(link,page){
  //   try {
  //     await page.goto(link, { waitUntil:  'load',timeout: 0});
  //     const html = await page.evaluate(() => document.querySelector('*').outerHTML);
  //     const $= cheerio.load(html);
  //     return $
  //   } catch (err) {
  //     console.error(err);
  //   }
  // }
  




  // async function scrapeComments(link,result){


    // for(let i=3;i<=1000;i++){
    //   console.log('page number' +" "+i)
      
    //   let thisLink=`${link}?page=${i}`
    //   let html=await getHtmlReq(thisLink).catch(err=>console.log(err))
    
    //   if(html){
    //     let $=cheerio.load(html)
    //   $('div.ugc-review').each(function(idx,el){
    //   // let datePublished=$(this).html()
    //   let thisHtml=$(this).html()
    //   let $1=cheerio.load(thisHtml)
    //   let SameAs=$1('a').attr('href')
    //   let datePublished=$1('span.recipe-review-date').text()
    //   let reviewBody=$1('div.recipe-review-body').text().trim()
    //   let name=$1('span.reviewer-name').text().trim()
    //   let ratingValue=$1('span.rating-star.active').length
    //   let rating=$1('span.review-star-text').text().trim()
    //   console.log(ratingValue,rating,name)
    //     })
      
    //   }
    //   else{
    //     break
    //   }
    // }
    
    
    
    // }
    