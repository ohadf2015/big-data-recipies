
const _=require('lodash')
const fs=require('fs')
const XLSX=require('xlsx')
const path=require('path')
const JSONStream = require('JSONStream')

let thatdata=[]


fs.readdirSync('./data').forEach(file=>{

    const RS=fs.createReadStream(path.join('./data',file))

    const parseStream = JSONStream.parse("*").on('data',function(data){thatdata.push(data)});
  
     RS.pipe(parseStream).on('end',function(hi){
 
        thatdata=_.filter(thatdata,function(o){
    // console.log(o.recipeData.mainEntityOfPage,o.recipeData.review.length)
  
    if(o&&o.mainEntityOfPage&&o.reviews&&o.reviews.length){
        return  true
    }
 })
// data=_.unionBy(data.recipeData,'mainEntityOfPage')
// console.log(data)
let recipesBook=[]
thatdata=thatdata.map(arr=>{
    arr.RecId=parseInt(arr.mainEntityOfPage.split('recipe/')[1].split('/')[0])
    arr.reviewsData=[]
    recipesBook.push({id:arr.RecId,name:arr.name,link:arr.mainEntityOfPage})
    arr.reviews.forEach(review=>{
        let object={}
        object[review.submitter_id]=review.rating
        arr.reviewsData.push(object)
    })
    return arr
})


let newData=_.cloneDeep(thatdata)
newData=newData.map(arr=>{
arr=_.pick(arr,['RecId','reviewsData'])
arr.reviewsData.forEach(review=>{
let reviewKey=Object.keys(review)
arr[reviewKey[0]]=review[reviewKey[0]]
})
delete arr.reviewsData
return arr
})


// newData=XLSX.utils.json_to_sheet(newData)
// XLSX.stream.to_csv(newData)

let result_xl=XLSX.utils.book_new({});
XLSX.utils.book_append_sheet(result_xl, newData, "ניסיון");
XLSX.writeFile(result_xl,'ניסיון.csv',{cellDates:true}); 

recipesBook=XLSX.utils.json_to_sheet(recipesBook)
let result_xl1=XLSX.utils.book_new({});
XLSX.utils.book_append_sheet(result_xl1, recipesBook, "ספר מתכונים");
XLSX.writeFile(result_xl1,'ספר מתכונים.xlsx',{cellDates:true}); 


 
     })


})
   




// console.log(file)
// let thisData=JSON.parse(fs.readFileSync(path.join('./data',file)))
// console.log(thisData.length)







