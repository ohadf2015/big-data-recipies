
const _ = require('lodash')
const fs = require('fs')
const XLSX = require('xlsx')
const path = require('path')
const JSONStream = require('JSONStream')

let usersCounter = 1
let usersIds = {}
let users = {}
let reviews = []
let counter = 0

const WS = fs.createWriteStream('./data/newRatings.dat')
const RS = fs.createReadStream('./data/allRecipes.json')

const parseStream = JSONStream.parse().on('data', function (data) {
    if (data && data.mainEntityOfPage && data.reviews && data.reviews.length > 5) {
        let recId = parseInt(data.mainEntityOfPage.split('recipe/')[1].split('/')[0])

        if (reviews.length > 0) {
            let flag = false

            for (let i = 0; i < reviews.length; i++) {
                if (reviews[i].recipeId == recId) {
                    flag = true
                    break
                }
            }

            if (!flag) {
                data.reviews.forEach(review => {
                    if (!usersIds[review.submitter_id]) {
                        usersIds[review.submitter_id] = usersCounter
                        users[usersCounter] = 1
                        usersCounter++;
                    }
                    else {
                        users[usersIds[review.submitter_id]]++
                    }
                    reviews.push({ userId: usersIds[review.submitter_id], rating: review.rating, recipeId: recId })
                })
            }


        }
        else {

            data.reviews.forEach(review => {
                if (!usersIds[review.submitter_id]) {
                    usersIds[review.submitter_id] = usersCounter
                    users[usersCounter] = 1
                    usersCounter++;
                }
                reviews.push({ userId: usersIds[review.submitter_id], rating: review.rating, recipeId: recId })
            })
        }


    }
    counter++;

    process.stdout.write('processing ' + ((counter / 85200) * 100).toFixed(2) + '% complete...\r');

});

RS.pipe(parseStream).on('end', function (hi) {

    finish()


})



const finish = () => {

    let usersToDel = []
    for (const key in users) {
        if (users.hasOwnProperty(key)) {
            const arr = users[key];
            if (arr < 10) {
                usersToDel.push(parseInt(key))
            }

        }
    }
    console.log(usersToDel)

    for (let i = 0; i < reviews.length; i++) {
        for (let k = 0; k < usersToDel.length; k++) {
            if (reviews[i].userId === usersToDel[k]) {
                reviews.splice(i, 1);
                i--

                break

            }
        }

    }


    reviews.forEach(arr => {

        WS.write(`${arr.userId}::${arr.rating}::${arr.recipeId}\n`)

    })


    reviews = JSON.stringify(reviews)
    fs.writeFileSync('./data/newReviewsCF.json', reviews)



}














